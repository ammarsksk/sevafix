"use client";

import { useParams } from "next/navigation";
import { useEffect, useRef, useState } from "react";

import { Card, ErrorBanner, FullPageSpinner, TextField } from "@/components/ui";
import { PM_USP_FIELDS, type FieldConfig } from "@/lib/sevafix/pm-usp-schema";
import { useApplication, useSaveDraft } from "@/lib/sevafix/queries";
import { SevaFixApiError } from "@/lib/sevafix/sevafix-api";
import type { DraftFields } from "@/lib/sevafix/sevafix-types";

const AUTOSAVE_DELAY_MS = 1200;

function fieldToInputValue(field: FieldConfig, value: unknown): string {
  if (value === null || value === undefined) return "";
  if (field.type === "boolean") return value ? "true" : "false";
  return String(value);
}

function inputValueToField(field: FieldConfig, raw: string): string | number | boolean | null {
  if (raw === "") return null;
  if (field.type === "boolean") return raw === "true";
  if (field.type === "integer") {
    const parsed = Number.parseInt(raw, 10);
    return Number.isNaN(parsed) ? null : parsed;
  }
  if (field.type === "number") {
    const parsed = Number.parseFloat(raw);
    return Number.isNaN(parsed) ? null : parsed;
  }
  return raw;
}

function FieldControl({
  field,
  value,
  onChange,
}: {
  field: FieldConfig;
  value: unknown;
  onChange: (next: unknown) => void;
}) {
  if (field.type === "select") {
    return (
      <label className="block">
        <span className="mb-1 block text-sm font-medium text-slate-800">{field.label}</span>
        <select
          className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-400"
          value={fieldToInputValue(field, value)}
          onChange={(e) => onChange(inputValueToField(field, e.target.value))}
        >
          <option value="">Select…</option>
          {field.options?.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        {field.helpText ? <span className="mt-1 block text-xs text-slate-500">{field.helpText}</span> : null}
      </label>
    );
  }

  if (field.type === "boolean") {
    return (
      <label className="block">
        <span className="mb-1 block text-sm font-medium text-slate-800">{field.label}</span>
        <div className="flex gap-2">
          {[
            { value: "true", label: "Yes" },
            { value: "false", label: "No" },
          ].map((opt) => (
            <button
              key={opt.value}
              type="button"
              onClick={() => onChange(inputValueToField(field, opt.value))}
              className={`rounded-md border px-3 py-1.5 text-sm ${
                fieldToInputValue(field, value) === opt.value
                  ? "border-slate-900 bg-slate-900 text-white"
                  : "border-slate-300 text-slate-700 hover:bg-slate-50"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </label>
    );
  }

  return (
    <TextField
      label={field.label}
      hint={field.helpText}
      type={field.type === "integer" || field.type === "number" ? "number" : "text"}
      value={fieldToInputValue(field, value)}
      onChange={(e) => onChange(inputValueToField(field, e.target.value))}
    />
  );
}

export default function EditDraftPage() {
  const params = useParams<{ id: string }>();
  const appId = params.id;
  const application = useApplication(appId);
  const saveDraft = useSaveDraft(appId);

  const [fields, setFields] = useState<DraftFields>({});
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);
  const [conflictMessage, setConflictMessage] = useState<string | null>(null);
  const initializedRef = useRef(false);
  const revisionRef = useRef(0);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!application.data) return;
    revisionRef.current = application.data.application.revision;
    if (!initializedRef.current) {
      setFields(application.data.application.draftFields ?? {});
      initializedRef.current = true;
    }
  }, [application.data]);

  useEffect(() => () => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
  }, []);

  function scheduleSave(nextFields: DraftFields) {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      try {
        const updated = await saveDraft.mutateAsync({
          fields: nextFields,
          expectedRevision: revisionRef.current,
        });
        revisionRef.current = updated.revision;
        setLastSavedAt(new Date());
        setConflictMessage(null);
      } catch (err) {
        if (err instanceof SevaFixApiError && err.status === 409) {
          setConflictMessage(
            "This application was updated elsewhere. Reloading the latest version — please redo your last change.",
          );
          initializedRef.current = false;
          await application.refetch();
        }
      }
    }, AUTOSAVE_DELAY_MS);
  }

  function onFieldChange(key: string, value: unknown) {
    const next = { ...fields, [key]: value as DraftFields[string] };
    setFields(next);
    scheduleSave(next);
  }

  if (application.isLoading) return <FullPageSpinner />;

  return (
    <div>
      <ErrorBanner
        message={application.error instanceof Error ? application.error.message : null}
      />
      <ErrorBanner message={conflictMessage} />
      <Card>
        <div className="mb-4 flex items-center justify-between text-xs text-slate-500">
          <span>Fields save automatically as you type.</span>
          <span>
            {saveDraft.isPending
              ? "Saving…"
              : lastSavedAt
                ? `Last saved ${lastSavedAt.toLocaleTimeString()}`
                : "Not saved yet"}
          </span>
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          {PM_USP_FIELDS.map((field) => (
            <FieldControl
              key={field.key}
              field={field}
              value={fields[field.key]}
              onChange={(value) => onFieldChange(field.key, value)}
            />
          ))}
        </div>
      </Card>
    </div>
  );
}
