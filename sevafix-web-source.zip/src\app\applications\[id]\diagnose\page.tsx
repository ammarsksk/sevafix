"use client";

import { useParams, useRouter } from "next/navigation";
import { useRef, useState } from "react";

import { Button, Card, ErrorBanner } from "@/components/ui";
import { REJECTION_DOCUMENT_TYPE } from "@/lib/sevafix/pm-usp-schema";
import { uploadDocument } from "@/lib/sevafix/document-upload";
import { useApplication, useCreateRepair, useDiagnose } from "@/lib/sevafix/queries";
import { sevaFixApi } from "@/lib/sevafix/sevafix-api";
import type { Diagnosis } from "@/lib/sevafix/sevafix-types";

const POLL_INTERVAL_MS = 2000;
const POLL_TIMEOUT_MS = 90_000;

export default function DiagnosePage() {
  const params = useParams<{ id: string }>();
  const appId = params.id;
  const router = useRouter();
  const application = useApplication(appId);
  const diagnose = useDiagnose(appId);
  const createRepair = useCreateRepair(appId);

  const [reasonText, setReasonText] = useState("");
  const [rejectionDocumentId, setRejectionDocumentId] = useState<string>("");
  const [uploading, setUploading] = useState(false);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [latestDiagnosis, setLatestDiagnosis] = useState<Diagnosis | null>(null);
  const stopRef = useRef(false);

  const documents = application.data?.documents ?? [];
  const diagnoses = [...(application.data?.diagnoses ?? [])].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );

  async function onUploadRejectionNotice(file: File | undefined) {
    if (!file) return;
    setError(null);
    setUploading(true);
    try {
      const { session } = await uploadDocument(appId, REJECTION_DOCUMENT_TYPE, file);
      setRejectionDocumentId(session.documentId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  async function onDiagnose() {
    setError(null);
    if (!reasonText && !rejectionDocumentId) {
      setError("Describe the rejection reason or attach the rejection notice.");
      return;
    }
    stopRef.current = false;
    setRunning(true);
    try {
      const job = await diagnose.mutateAsync({
        reasonText: reasonText || undefined,
        rejectionDocumentId: rejectionDocumentId || undefined,
      });
      const deadline = Date.now() + POLL_TIMEOUT_MS;
      while (!stopRef.current && Date.now() < deadline) {
        const latest = await sevaFixApi.job(job.jobId);
        if (latest.status === "COMPLETED") break;
        if (latest.status === "FAILED") throw new Error("Diagnosis job failed. Please try again.");
        await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
      }
      const refreshed = await application.refetch();
      const sorted = [...(refreshed.data?.diagnoses ?? [])].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
      setLatestDiagnosis(sorted[0] ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not run diagnosis");
    } finally {
      setRunning(false);
    }
  }

  async function onCreateRepair(diagnosisId?: string) {
    setError(null);
    try {
      await createRepair.mutateAsync(diagnosisId);
      router.push(`/applications/${appId}/edit`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create repair draft");
    }
  }

  const shown = latestDiagnosis ?? diagnoses[0] ?? null;

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="mb-3 text-sm font-semibold text-slate-700">Diagnose a rejection</h2>
        <ErrorBanner message={error} />
        <label className="block">
          <span className="mb-1 block text-sm font-medium text-slate-800">Rejection reason</span>
          <textarea
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-400"
            rows={4}
            value={reasonText}
            onChange={(e) => setReasonText(e.target.value)}
            placeholder="Paste or describe why the application was rejected"
          />
        </label>

        <div className="mt-4">
          <span className="mb-1 block text-sm font-medium text-slate-800">Rejection notice document</span>
          <div className="flex flex-wrap items-center gap-2">
            <select
              className="rounded-md border border-slate-300 px-3 py-2 text-sm"
              value={rejectionDocumentId}
              onChange={(e) => setRejectionDocumentId(e.target.value)}
            >
              <option value="">None</option>
              {documents.map((doc) => (
                <option key={doc.documentId} value={doc.documentId}>
                  {doc.documentType} ({doc.state})
                </option>
              ))}
            </select>
            <label>
              <span
                className={`inline-flex cursor-pointer items-center gap-2 rounded-md border border-slate-300 px-3 py-1.5 text-sm hover:bg-slate-50 ${
                  uploading ? "pointer-events-none opacity-60" : ""
                }`}
              >
                {uploading ? "Uploading…" : "Upload rejection notice"}
              </span>
              <input
                type="file"
                className="hidden"
                accept=".pdf,.jpg,.jpeg,.png,.tif,.tiff"
                disabled={uploading}
                onChange={(e) => onUploadRejectionNotice(e.target.files?.[0])}
              />
            </label>
          </div>
        </div>

        <Button className="mt-4" onClick={onDiagnose} loading={running}>
          Diagnose
        </Button>
      </Card>

      {shown ? (
        <Card>
          <h2 className="mb-2 text-sm font-semibold text-slate-700">Latest diagnosis</h2>
          <p className="text-sm font-medium text-slate-900">
            {shown.result.category.replaceAll("_", " ")}
          </p>
          <p className="mt-1 text-sm text-slate-600">{shown.result.summary}</p>
          {shown.result.recommendedActions.length > 0 ? (
            <ul className="mt-2 list-inside list-disc text-sm text-slate-700">
              {shown.result.recommendedActions.map((action, i) => (
                <li key={i}>{action}</li>
              ))}
            </ul>
          ) : null}
          {shown.result.citations?.length ? (
            <p className="mt-2 text-xs text-slate-500">
              Sources: {shown.result.citations.map((c) => c.uri ?? c.citationId).join(", ")}
            </p>
          ) : null}
          <Button
            className="mt-4"
            onClick={() => onCreateRepair(shown.diagnosisId)}
            loading={createRepair.isPending}
          >
            Start repair draft
          </Button>
        </Card>
      ) : null}

      {diagnoses.length > 1 ? (
        <Card>
          <h2 className="mb-3 text-sm font-semibold text-slate-700">Past diagnoses</h2>
          <ul className="space-y-2">
            {diagnoses.slice(1).map((d) => (
              <li key={d.diagnosisId} className="text-sm text-slate-600">
                {new Date(d.createdAt).toLocaleString()} — {d.result.category.replaceAll("_", " ")}
              </li>
            ))}
          </ul>
        </Card>
      ) : null}
    </div>
  );
}
