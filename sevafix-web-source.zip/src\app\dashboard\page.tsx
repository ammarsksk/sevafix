"use client";

import Link from "next/link";

import { ProtectedRoute } from "@/components/route-guards";
import { Button, Card, ErrorBanner, FullPageSpinner, PageHeader, StatusChip } from "@/components/ui";
import { useApplications, useMe } from "@/lib/sevafix/queries";
import { lifecycleChip } from "@/lib/status";

function DashboardContent() {
  const me = useMe();
  const applications = useApplications();

  if (me.isLoading || applications.isLoading) return <FullPageSpinner />;

  return (
    <div>
      <PageHeader
        title={`Welcome${me.data?.displayName ? `, ${me.data.displayName}` : ""}`}
        description="Track your government scheme applications from draft to submission."
        action={
          <Link href="/schemes">
            <Button>Start a new application</Button>
          </Link>
        }
      />

      {me.data?.profileStatus === "EMPTY" ? (
        <Card className="mb-6 border-amber-300 bg-amber-50">
          <p className="text-sm text-amber-800">
            Your profile is incomplete.{" "}
            <Link href="/settings" className="underline">
              Add your name and notification preferences
            </Link>
            .
          </p>
        </Card>
      ) : null}

      <ErrorBanner message={applications.error instanceof Error ? applications.error.message : null} />

      {applications.data?.items.length === 0 ? (
        <Card>
          <p className="text-sm text-slate-600">
            You have not started an application yet.{" "}
            <Link href="/schemes" className="underline">
              Browse supported schemes
            </Link>
            .
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {applications.data?.items.map((app) => {
            const chip = lifecycleChip(app.lifecycleStatus);
            return (
              <Link key={app.appId} href={`/applications/${app.appId}/edit`}>
                <Card className="flex items-center justify-between transition-shadow hover:shadow-md">
                  <div>
                    <p className="font-medium text-slate-900">{app.schemeId}</p>
                    <p className="text-xs text-slate-500">
                      Updated {new Date(app.updatedAt).toLocaleString()}
                    </p>
                  </div>
                  <StatusChip spec={chip} />
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  );
}
