// The backend has no dynamic form-definition endpoint yet (see handoff section 6/11).
// This is the documented field set for scheme `pm-usp-csss`, kept in one place so the
// draft form can render and validate it without hardcoding shapes across components.

export type FieldType = "text" | "integer" | "number" | "select" | "boolean";

export interface FieldOption {
  value: string;
  label: string;
}

export interface FieldConfig {
  key: string;
  label: string;
  type: FieldType;
  helpText?: string;
  options?: FieldOption[];
}

export const PM_USP_SCHEME_ID = "pm-usp-csss";

export const PM_USP_FIELDS: FieldConfig[] = [
  {
    key: "student.primaryName",
    label: "Full name",
    type: "text",
    helpText: "Enter the name exactly as it appears on your official evidence.",
  },
  {
    key: "student.familyAnnualIncomeINR",
    label: "Annual family income (INR)",
    type: "integer",
  },
  {
    key: "student.enrolmentMode",
    label: "Enrolment mode",
    type: "select",
    helpText: "Use Regular for a regular course.",
    options: [
      { value: "REGULAR", label: "Regular" },
      { value: "DISTANCE", label: "Distance" },
      { value: "PART_TIME", label: "Part-time" },
    ],
  },
  {
    key: "student.courseType",
    label: "Course type",
    type: "select",
    helpText: "Diploma currently fails the eligibility check for this scheme.",
    options: [
      { value: "DEGREE", label: "Degree" },
      { value: "DIPLOMA", label: "Diploma" },
      { value: "POSTGRADUATE", label: "Postgraduate" },
    ],
  },
  {
    key: "student.receivesOtherScholarship",
    label: "Receiving another scholarship or fee reimbursement?",
    type: "boolean",
  },
  {
    key: "student.boardPercentile",
    label: "Class XII board percentile",
    type: "number",
  },
  {
    key: "student.hasAcademicGap",
    label: "Do you have an academic gap?",
    type: "boolean",
  },
];

export const PM_USP_EVIDENCE_TYPES = [
  { value: "INCOME_CERTIFICATE", label: "Income certificate" },
  { value: "ADMISSION_LETTER", label: "Admission letter" },
  { value: "MARKSHEET", label: "Marksheet" },
  { value: "IDENTITY_PROOF", label: "Identity proof" },
];

export const REJECTION_DOCUMENT_TYPE = "REJECTION_NOTICE";
